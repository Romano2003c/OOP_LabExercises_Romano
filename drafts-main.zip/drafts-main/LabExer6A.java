package Romano_McAndrei;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.AccessMode.*;
import java.util.Random;

public class LabExer6A {

    
    public static void main(String[] args) {
       Path FL1 = Paths.get("C:\\Users\\user\\Desktop\\words\\words.txt");
       System.out.println("Path is " + FL1.toString());
       try{
           FL1.getFileSystem().provider().checkAccess
                   (FL1, READ,EXECUTE);
           System.out.println("The file can be read and executed");
       }
       catch(IOException e)
       {
           System.out.println("The file cannot be used.");
       }
       Scanner scan = new Scanner(System.in);
       Random entity = new Random();
       int Ranum = entity.nextInt(10);
       
       
       
       
       
    }
}
